==========================================================================================
Infinity Sword Datapack v1.0 - README
==========================================================================================
Info:
!!! Datapack requires "Allow Cheats: ON" to work properly !!!
!!! Datapack requires minecraft version 1.19+ and custom resourcepack (link - "") !!!
!!! After logging into the server it is recommended to use the /reload command !!!

Credits:
Copyright © 2022 YuXyy
==========================================================================================